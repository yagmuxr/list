??  

#include <conio.h> 

#include <time.h> 

#include<stdlib.h> 

#include<locale.h> 

#include "bbdol.h" 

using namespace std; 

  

node* terstensirala(node* list) 

{ 

	node* temp; 

	node* prev=NULL; 

	node* ylist=list; 

	while(list->link!=NULL) 

	{ 

		temp=list->link; 

		list->link = prev; 

		prev=ylist; 

		ylist=temp; 

		 

	} 

	list=prev; 

	dumplist(list); 

	return(list); 

     

} 

int main() 

{ 

	node* l1=NULL; 

	addhead(newnode(),l1); 

	addhead(newnode(),l1); 

	addhead(newnode(),l1); 

	addhead(newnode(),l1); 

	dumplist(l1); 

	terstensirala(l1); 

} 
