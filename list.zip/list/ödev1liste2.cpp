#include <iostream> 

#include <conio.h> 

#include <time.h> 

#include<stdlib.h> 

#include<locale.h> 

using namespace std; 

struct node 

{ 

	int data; 

	node* link; 

}; 

void dumplist(node* list) 

{ 

	if(list!=NULL) 

	{ 

	int i=0; 

	node* ylist=list; 

	do 

	{ 

		cout<<"Listenin "<<++i<<". nodunun "<<endl; 

		cout<<"adresi: "<<list<<endl; 

		cout<<"datas�: "<<list->data<<endl; 

		cout<<"linki: "<<list->link<<endl; 

		list=list->link; 

	}while(list!=ylist); 

} 

} 

node* newnode() 

{ 

	node* newnode=new node; 

	newnode->link=NULL; 

	int b=rand()%451+50; 

	newnode->data=b; 

	return(newnode); 

} 

  

node* last(node* list) 

{ 

if(list!=NULL)       

while(list->link!=NULL) 

     list=list->link;      

node* last=list; 

return(last);       

} 

void addhead(node* node_, node*& list) 

{ 

	node_->link=list; 

	list=node_; 

} 

node* liste_yap(node* list, int a) 

{ 

	node* ylist=list; 

	for(int i=0; i<a;i++){ 

	addhead(newnode(),list); 

} 

dumplist(list); 

} 

  

int main(){ 

	setlocale(LC_ALL,"Turkish"); 

	srand(time(NULL)); 

	node* l1=NULL; 

	int b; 

	cout << "Node say�s�n� giriniz: "; 

	cin>>b; 

	liste_yap(l1,b); 

	 

	 

} 
