//Kendisine parametre olarak gelen bir ba�l� do�rusal listeden yine kendisine parametre olarak gelen integer veriye sahip nodelar� silen, sildi�i node say�s�n� �a�r�ld��� yere g�nderen nodesil() 
#include <conio.h>
#include <time.h>
#include<stdlib.h>
#include<locale.h>
using namespace std;
struct node
{
	int data;
	node* link;
};
node* cuthead(node*& list)
{
	node* cuthead=list;
	if(list!=NULL)
	{
		list=list->link;
		cuthead->link=NULL;
	}
	return(cuthead);
}
bool advance(node*& point)
{
	bool advance=false;
	if(point!=NULL && point->link!=NULL)
	{
		point=point->link;
		advance=true;
	}
	return(advance);
}
bool nodesil()
{
  bool deletenode=false;
  if(list==NULL) return(deletenode);
  if(list==node_)
  {
  	free(cuthead(list));
  	deletenode=true;
  	return(deletenode);
  }
  else
  {
  	node* point=list;
  	do{
  	if(point->link==node_)
  	{
  		free(cuthead(point->link));
  		deletenode=true;
  		return(deletenode);
	  }
	  }while(advance(point));
  }
}
int main()
{
	
}

